// src/components/HeroSection.jsx
import { useState, useEffect } from 'react';
import { ArrowPathIcon } from '@heroicons/react/24/outline';

export default function HeroSection({ onPulseClick, loading }) {
  // Array of phrases to cycle through
  const phrases = [
    'institutional investors',
    'hedge funds',
    'political figures',
    'top analysts',
    'venture capitalists',
  ];

  // State variables for typing effect
  const [currentPhraseIndex, setCurrentPhraseIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [typingSpeed, setTypingSpeed] = useState(100); // Slower typing speed

  // Typing effect logic
  useEffect(() => {
    let timer;

    const handleType = () => {
      const currentPhrase = phrases[currentPhraseIndex % phrases.length];
      if (!isDeleting) {
        setDisplayedText(currentPhrase.substring(0, displayedText.length + 1));
        if (displayedText.length + 1 === currentPhrase.length) {
          setIsDeleting(true);
          setTypingSpeed(1200); // Pause before deleting
        } else {
          setTypingSpeed(100); // Typing speed
        }
      } else {
        setDisplayedText(currentPhrase.substring(0, displayedText.length - 1));
        if (displayedText.length === 0) {
          setIsDeleting(false);
          setCurrentPhraseIndex((currentPhraseIndex + 1) % phrases.length);
          setTypingSpeed(300); // Pause before typing next phrase
        } else {
          setTypingSpeed(60); // Deleting speed
        }
      }
    };

    timer = setTimeout(handleType, typingSpeed);
    return () => clearTimeout(timer);
  }, [displayedText, isDeleting, typingSpeed]);

  return (
    <main className="relative flex flex-col items-center justify-center min-h-screen text-white">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900"></div>

      {/* Content Container */}
      <div className="relative z-10 flex flex-col items-center text-center px-4 sm:px-6 lg:px-8">
        {/* Main Heading */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold mb-6 bg-gradient-to-r from-teal-400 via-blue-500 to-green-400 bg-clip-text text-transparent">
          Discover the Hidden Gems of the Stock Market
        </h1>

        {/* Typing Effect Subheading */}
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-semibold mb-8">
          Uncover the stocks that{' '}
          <span className="bg-gradient-to-r from-teal-400 via-blue-500 to-green-400 bg-clip-text text-transparent">
            {displayedText}
          </span>{' '}
          are investing in
        </h2>

        {/* Call to Action Button */}
        {!loading ? (
          <button
            onClick={onPulseClick}
            className="mt-8 px-8 py-4 rounded-full text-xl font-bold bg-gradient-to-r from-teal-400 to-blue-500 text-white shadow-lg hover:shadow-xl transform hover:scale-105 transition-transform"
          >
            Find Pulse Stocks
          </button>
        ) : (
          <div className="mt-10 flex flex-col items-center">
            <ArrowPathIcon className="h-16 w-16 animate-spin text-green-400" />
            <p className="mt-6 text-lg text-gray-300">Performing Market Research...</p>
          </div>
        )}
      </div>
    </main>
  );
}
